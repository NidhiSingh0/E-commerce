import React from 'react'
import './DescriptionBox.css'

const DescriptionBox = () => {
  return (
    <div className='descriptionbox'>
      <div className="descriptionbox-navigator">
        <div className="descriptionbox-nav-box">Description</div>
        <div className="descriptionbox-nav-box fade">Reviews (122)</div>
      </div>
      <div className="descriptionbox-description">
        <p>An ecommerce website is an online shopping and purchasing portal for your business. It provides visitors with the ability to easily find products they’re looking for, reach out to customer service for help while browsing your products or services, and complete purchases all without leaving your website.</p>
        <p>Ecommerce websites have many of the same requirements as websites that don't include online stores including the need for a hosting provider, content management capabilities, and regular updates.</p>
      </div>
    </div>
  )
}

export default DescriptionBox
